# Pembukuan Sabun - Android APK project

This project wraps the mobile bookkeeping HTML app in an Android WebView.

## Build APK
- Open this folder in Android Studio, sync Gradle, then Build > Build APK(s).
- Or push the project to a GitHub repository. The workflow `.github/workflows/build-apk.yml` can build a debug APK; run it under Actions (or it runs on push to `main`) and download the artifact.

APK output: `app/build/outputs/apk/debug/app-debug.apk`

The bookkeeping data uses browser localStorage inside the WebView. Clear app data/uninstalling can delete it; use the app's Backup feature periodically.
